package ch.tbz;

public class HangmanGame1 {

    // Globale Variablen (Instanzvariablen)
    private String wordToGuess;
    private String hiddenWord;
    private int maxTries;
    private int wrongTries;
    private String guessedLetters;

    // Wortliste mit 20 Wörtern
    private static final String[] WORDS = {
        "stickman", "computer", "java", "hangman", "development", "algorithm",
        "programming", "language", "education", "science", "machine", "learning",
        "robotics", "software", "hardware", "internet", "network", "database",
        "python", "debugging"
    };

    // Index für aktuelles Wort
    private static int currentWordIndex = 0;

    // Konstruktor: Spiel initialisieren
    public HangmanGame1(int maxTries) {
        this.wordToGuess = WORDS[currentWordIndex];
        this.hiddenWord = "_".repeat(wordToGuess.length());
        this.maxTries = maxTries;
        this.wrongTries = 0;
        this.guessedLetters = "";
    }

    // SPIELSTART
    public void startGame() {
        System.out.println("Willkommen beim Hangman-Spiel!");
        System.out.println("Errate das Wort: " + hiddenWord);

        // HAUPTSCHLEIFE → Solange nicht verloren und nicht vollständig erraten
        while (wrongTries < maxTries && hiddenWord.contains("_")) {

            drawStickman(wrongTries); // Zeichnung je nach Fehlerzahl
            System.out.println("\nAktuelles Wort: " + hiddenWord);
            System.out.println("Geratene Buchstaben: " + guessedLetters);

            String input = inputString("Gib einen Buchstaben ein: ").toLowerCase();

            // Eingabeprüfung
            if (input.length() != 1) {
                System.out.println("Bitte gib nur einen Buchstaben ein!");
                continue;
            }

            char guessedLetter = input.charAt(0);

            // Bereits geratene Buchstaben überspringen
            if (guessedLetters.contains(String.valueOf(guessedLetter))) {
                System.out.println("Diesen Buchstaben hast du schon geraten!");
                continue;
            }

            guessedLetters += guessedLetter; // Hinzufügen zur Ratehistorie

            // Richtige Buchstabe?
            if (wordToGuess.contains(String.valueOf(guessedLetter))) {
                hiddenWord = updateState(guessedLetter); // aktualisiere verstecktes Wort
            } else {
                wrongTries++; // falscher Versuch
            }
        }

        // SPIELENDE
        if (hiddenWord.equals(wordToGuess)) {
            System.out.println("\nGlückwunsch! Du hast das Wort erraten: " + wordToGuess);
        } else {
            drawStickman(wrongTries);
            System.out.println("\nGame Over! Das richtige Wort war: " + wordToGuess);
        }

        // Nächstes Wort vorbereiten
        currentWordIndex = (currentWordIndex + 1) % WORDS.length;
    }

    // Eingabe lesen
    private static String inputString(String prompt) {
        System.out.print(prompt);
        java.io.Console console = System.console();
        if (console != null) {
            return console.readLine();
        } else {
            try {
                byte[] inputBytes = new byte[100];
                int length = System.in.read(inputBytes);
                return new String(inputBytes, 0, length).trim();
            } catch (Exception e) {
                return "";
            }
        }
    }

    // ASCII-Figur zeichnen
    private static void drawStickman(int wrongTries) {
        System.out.println("\nFehler: " + wrongTries + " von 6");
        switch (wrongTries) {
            case 0 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 1 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 2 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println("  |   |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 3 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println(" /|   |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 4 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println(" /|\\  |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 5 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println(" /|\\  |");
                System.out.println(" /    |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 6 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println(" /|\\  |");
                System.out.println(" / \\  |");
                System.out.println("      |");
                System.out.println("=========");
            }
        }
    }

    // Verstecktes Wort aktualisieren, wenn Buchstabe richtig war
    private String updateState(char guessedLetter) {
        StringBuilder newHiddenWord = new StringBuilder(hiddenWord);
        for (int i = 0; i < wordToGuess.length(); i++) {
            if (wordToGuess.charAt(i) == guessedLetter) {
                newHiddenWord.setCharAt(i, guessedLetter);
            }
        }
        return newHiddenWord.toString();
    }

    // PROGRAMMSTART
    public static void main(String[] args) {
        while (currentWordIndex < WORDS.length) {
            HangmanGame1 game = new HangmanGame1(6);
            game.startGame(); // Starte Spiel mit nächstem Wort
        }
        System.out.println("Alle Wörter wurden gespielt. Vielen Dank fürs Mitspielen!");
    }
}
