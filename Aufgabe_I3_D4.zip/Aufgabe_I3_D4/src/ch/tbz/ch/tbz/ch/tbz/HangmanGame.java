package ch.tbz;

public class HangmanGame {

    public static void main(String[] args) {
        String wordToGuess = "stickman"; // Das Wort, das erraten werden muss
        String hiddenWord = "_".repeat(wordToGuess.length()); // Verstecktes Wort mit _

        int maxTries = 6; // Maximale Anzahl an Fehlversuchen
        int wrongTries = 0; // Zähler für falsche Versuche
        String guessedLetters = ""; // Bereits geratene Buchstaben

        System.out.println("Willkommen beim Hangman-Spiel!");
        System.out.println("Errate das Wort: " + hiddenWord);

        // Spiel läuft, solange noch Versuche übrig sind und nicht alles erraten wurde
        while (wrongTries < maxTries && hiddenWord.contains("_")) {
            drawStickman(wrongTries); // Zeichnet den aktuellen Stand der Figur

            System.out.println("\nAktuelles Wort: " + hiddenWord);
            System.out.println("Geratene Buchstaben: " + guessedLetters);

            String input = inputString("Gib einen Buchstaben ein: ").toLowerCase(); // Eingabe eines Buchstabens

            if (input.length() != 1) { // Eingabe prüfen
                System.out.println("Bitte gib nur einen Buchstaben ein!");
                continue;
            }

            char guessedLetter = input.charAt(0); // Erstes Zeichen übernehmen

            if (guessedLetters.contains(String.valueOf(guessedLetter))) { // Schon geraten?
                System.out.println("Diesen Buchstaben hast du schon geraten!");
                continue;
            }

            guessedLetters += guessedLetter; // Zur Liste hinzufügen

            if (wordToGuess.contains(String.valueOf(guessedLetter))) {
                // Falls richtig geraten: Stelle im Wort aufdecken
                StringBuilder newHiddenWord = new StringBuilder(hiddenWord);
                for (int i = 0; i < wordToGuess.length(); i++) {
                    if (wordToGuess.charAt(i) == guessedLetter) {
                        newHiddenWord.setCharAt(i, guessedLetter);
                    }
                }
                hiddenWord = newHiddenWord.toString();
            } else {
                wrongTries++; // Sonst Fehlerzähler erhöhen
            }
        }

        // Spielende: Gewonnen oder verloren
        if (hiddenWord.equals(wordToGuess)) {
            System.out.println("\nGlückwunsch! Du hast das Wort erraten: " + wordToGuess);
        } else {
            drawStickman(wrongTries); // Finale Zeichnung
            System.out.println("\nGame Over! Das richtige Wort war: " + wordToGuess);
        }
    }

    // Liest eine Texteingabe vom Benutzer ein (ohne Scanner)
    private static String inputString(String prompt) {
        System.out.print(prompt);
        java.io.Console console = System.console();
        if (console != null) {
            return console.readLine(); // Falls Konsole verfügbar
        } else {
            try {
                byte[] inputBytes = new byte[100];
                int length = System.in.read(inputBytes); // Eingabe vom Terminal
                return new String(inputBytes, 0, length).trim(); // Eingabe als Text zurückgeben
            } catch (Exception e) {
                return "";
            }
        }
    }

    // Zeichnet den aktuellen Stand des Hängemanns je nach Fehleranzahl
    private static void drawStickman(int wrongTries) {
        System.out.println("\nFehler: " + wrongTries + " von 6");
        switch (wrongTries) {
            case 0 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 1 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |"); // Kopf
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 2 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println("  |   |"); // Körper
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 3 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println(" /|   |"); // Ein Arm
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 4 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println(" /|\\  |"); // Beide Arme
                System.out.println("      |");
                System.out.println("      |");
                System.out.println("=========");
            }
            case 5 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println(" /|\\  |");
                System.out.println(" /    |"); // Ein Bein
                System.out.println("      |");
                System.out.println("=========");
            }
            case 6 -> {
                System.out.println("  -----");
                System.out.println("  |   |");
                System.out.println("  O   |");
                System.out.println(" /|\\  |");
                System.out.println(" / \\  |"); // Beide Beine
                System.out.println("      |");
                System.out.println("=========");
            }
        }
    }
}
